package com.arka.arkavalenzuela;

import org.junit.jupiter.api.Test;

public class ArkajvalenzuelaApplicationTest {

    @Test
    public void testMainApplicationClassExists() {
        // Simple test que verifica que la clase principal existe
        // Sin inicializar el contexto completo de Spring
        assert ArkajvalenzuelaApplication.class != null;
    }
}